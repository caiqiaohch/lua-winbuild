print("Hello from Lua 1.1")
